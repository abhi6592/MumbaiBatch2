package com;

public class GitHubClass {

	public static void main(String[] args) {
		System.out.println("Hello Github!!!!");

	}

}
